package version

import (
	"github.com/reapchain/reapchain-core/version"
)

// TODO: eliminate this after some version refactor

const Version = version.ABCIVersion
