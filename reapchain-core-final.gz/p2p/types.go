package p2p

import (
	"github.com/reapchain/reapchain-core/p2p/conn"
)

type ChannelDescriptor = conn.ChannelDescriptor
type ConnectionStatus = conn.ConnectionStatus
