---
order: 9
---

# RPC

The RPC documentation is hosted here:

- [https://docs.reapchain-core.com/master/rpc/](https://docs.reapchain-core.com/master/rpc/)

To update the documentation, edit the relevant `godoc` comments in the [rpc/core directory](https://github.com/reapchain/reapchain-core/blob/v0.34.x/rpc/core).
