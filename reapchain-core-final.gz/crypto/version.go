package crypto

const Version = "0.9.0-dev"
